<?php
$id_solicitado = htmlspecialchars($_GET["id"]);
//$cali = htmlspecialchars($_GET["calidad"]);
if ($id_solicitado == "CARACOL_HD") {
$alfin = "778902";
}
elseif ($id_solicitado == "CARACOL_SD") {
$alfin = "778835";
}
elseif ($id_solicitado == "SENAL_COLOMBIA_HD") {
$alfin = "778918";
}
elseif ($id_solicitado == "CANAL_INSTITUCIONAL") {
$alfin = "778903";
}
elseif ($id_solicitado == "CANAL_INSTITUCIONAL_HD") {
$alfin = "758347";
}
elseif ($id_solicitado == "CANAL_CAPITAL") {
$alfin = "778809";
}
elseif ($id_solicitado == "WINSPORTS_HD") {
$alfin = "717016";
}
elseif ($id_solicitado == "CANAL_UNO_HD") {
$alfin = "778853";
}
elseif ($id_solicitado == "ESPN_HD") {
$alfin = "763498";
}
elseif ($id_solicitado == "ESPN_2_HD") {
$alfin = "759422";
}
elseif ($id_solicitado == "ESPN_3_HD") {
$alfin = "778892";
}
elseif ($id_solicitado == "ESPN_PLUS_HD") {
$alfin = "778963";
}
elseif ($id_solicitado == "FOX_SPORTS_HD") {
$alfin = "763489";
}
elseif ($id_solicitado == "FOX_SPORTS2_HD") {
$alfin = "739485";
}
elseif ($id_solicitado == "FOX_SPORTS3_HD") {
$alfin = "763417";
}
elseif ($id_solicitado == "FOXSP1_MX_HD") {
$alfin = "762787";
}
elseif ($id_solicitado == "FOXSP2_MX_HD") {
$alfin = "762801";
}
elseif ($id_solicitado == "FOXSP3_MX_HD") {
$alfin = "762802";
}
elseif ($id_solicitado == "CANAL_DE_LAS_ESTRELLAS") {
$alfin = "762288";
}
elseif ($id_solicitado == "ESTRELLAS_HD") {
$alfin = "778888";
}
elseif ($id_solicitado == "EL_TIEMPO") {
$alfin = "778838";
}
elseif ($id_solicitado == "RCN_HD") {
$alfin = "778872";
}
elseif ($id_solicitado == "NUESTRA_TELE") {
$alfin = "778836";
}
elseif ($id_solicitado == "CLARO_SPORTS_LATAM_HD") {
$alfin = "717017";
}
elseif ($id_solicitado == "CABLENOTICIAS_HD") {
$alfin = "778915";
}
elseif ($id_solicitado == "CLARO_SPORTS_COL_HD") {
$alfin = "717022";
}
elseif ($id_solicitado == "CLARO_MUSICA_A") {
$alfin = "778831";
}
elseif ($id_solicitado == "CLARO_MUSICA_B") {
$alfin = "778811";
}
elseif ($id_solicitado == "CNN_ESPANOL") {
$alfin = "773793";
}
elseif ($id_solicitado == "CONCERT_CHANNEL_HD") {
$alfin = "717024";
}
elseif ($id_solicitado == "TOONCAST") {
$alfin = "773759";
}
elseif ($id_solicitado == "BOOMERANG") {
$alfin = "773692";
}
elseif ($id_solicitado == "CARTOON_NETWORK_HD") {
$alfin = "773649";
}
elseif ($id_solicitado == "SPACE_HD") {
$alfin = "762211";
}
elseif ($id_solicitado == "GOLDEN_PREMIER_HD") {
$alfin = "758497";
}
elseif ($id_solicitado == "RADIOLA") {
$alfin = "717020";
}
elseif ($id_solicitado == "VALLENATO") {
$alfin = "717021";
}
elseif ($id_solicitado == "K_MUSIC") {
$alfin = "717018";
}
elseif ($id_solicitado == "HTV") {
$alfin = "773644";
}
elseif ($id_solicitado == "HBO_HD") {
$alfin = "762359";
}
elseif ($id_solicitado == "HBO_HD_SUB") {
$alfin = "750911";
}
elseif ($id_solicitado == "HBO_PLUS_HD") {
$alfin = "758578";
}
elseif ($id_solicitado == "HBO_2_HD") {
$alfin = "762272";
}
elseif ($id_solicitado == "HBO_SIGNATURE_HD") {
$alfin = "758603";
}
elseif ($id_solicitado == "HBO_FAMILY_HD") {
$alfin = "762235";
}
elseif ($id_solicitado == "MAX_UP_HD") {
$alfin = "762271";
}
elseif ($id_solicitado == "MAX_PRIME_HD") {
$alfin = "758604";
}
elseif ($id_solicitado == "FOX_COMEDY_HD") {
$alfin = "745920";
}
elseif ($id_solicitado == "FOX_CLASSICS_HD") {
$alfin = "745921";
}
elseif ($id_solicitado == "FOX_CINEMA_HD") {
$alfin = "762249";
}
elseif ($id_solicitado == "FOX_CINEMA_HD_SUB") {
$alfin = "745736";
}
elseif ($id_solicitado == "FOXFAMILY_HD") {
$alfin = "746478";
}
elseif ($id_solicitado == "FOXACTION_HD") {
$alfin = "745834";
}
elseif ($id_solicitado == "FOXMOVIES_HD") {
$alfin = "745939";
}
elseif ($id_solicitado == "FOX_SERIES_HD") {
$alfin = "763416";
}
elseif ($id_solicitado == "FOX1_HD") {
$alfin = "784978";
}
elseif ($id_solicitado == "FOX1_HD_SUB") {
$alfin = "745832";
}
elseif ($id_solicitado == "FOXMX_HD") {
$alfin = "762768";
}
elseif ($id_solicitado == "FOXNEWS") {
$alfin = "773785";
}
elseif ($id_solicitado == "FOX_HD") {
$alfin = "773866";
}
elseif ($id_solicitado == "FOX_LIFE_HD") {
$alfin = "773901";
}
elseif ($id_solicitado == "GOLDEN_PREMIER_HD") {
$alfin = "758497";
}
elseif ($id_solicitado == "GOLDEN_HD") {
$alfin = "778816";
}
elseif ($id_solicitado == "FXMMX_HD") {
$alfin = "773876";
}
elseif ($id_solicitado == "TELEMUNDO") {
$alfin = "768768";
}
elseif ($id_solicitado == "TELEMUNDO_HD") {
$alfin = "778942";
}
elseif ($id_solicitado == "RCN_TELENOVELAS") {
$alfin = "778865";
}
elseif ($id_solicitado == "TLNOVELAS") {
$alfin = "778845";
}
elseif ($id_solicitado == "TELECARIBE") {
$alfin = "758400";
}
elseif ($id_solicitado == "TELECARIBE_2") {
$alfin = "778829";
}
elseif ($id_solicitado == "TELEAMIGA") {
$alfin = "778884";
}
elseif ($id_solicitado == "TRO") {
$alfin = "758407";
}
elseif ($id_solicitado == "AE_MUNDO_HD") {
$alfin = "754222";
}
elseif ($id_solicitado == "ALJAZEERA_HD") {
$alfin = "762215";
}
elseif ($id_solicitado == "AMC_HD") {
$alfin = "728275";
}
elseif ($id_solicitado == "ANIMAL_PLANET_HD") {
$alfin = "778907";
}
elseif ($id_solicitado == "ANTENA3_HD") {
$alfin = "758424";
}
elseif ($id_solicitado == "ARIRANG") {
$alfin = "778837";
}
elseif ($id_solicitado == "AXN_HD") {
$alfin = "758481";
}
elseif ($id_solicitado == "AZCORAZON_HD") {
$alfin = "778914";
}
elseif ($id_solicitado == "AZMUNDO_HD") {
$alfin = "739482";
}
elseif ($id_solicitado == "BABYTV") {
$alfin = "739480";
}
elseif ($id_solicitado == "BABYTV_MX") {
$alfin = "762788";
}
elseif ($id_solicitado == "BBC_WORLD") {
$alfin = "762224";
}
elseif ($id_solicitado == "BLOOMBERG") {
$alfin = "762250";
}
elseif ($id_solicitado == "BLOOMBERG_HD") {
$alfin = "778890";
}
elseif ($id_solicitado == "CANAL_CLARO") {
$alfin = "717025";
}
elseif ($id_solicitado == "CANAL_CLARO_HD") {
$alfin = "762306";
}
elseif ($id_solicitado == "CINECANAL_HD") {
$alfin = "773940";
}
elseif ($id_solicitado == "CINELATINO") {
$alfin = "762242";
}
elseif ($id_solicitado == "CINEMAPLUS") {
$alfin = "778851";
}
elseif ($id_solicitado == "CINEMAX") {
$alfin = "771877";
}
elseif ($id_solicitado == "CINEMA_DINAMITA") {
$alfin = "762300";
}
elseif ($id_solicitado == "CITY_TV") {
$alfin = "758335";
}
elseif ($id_solicitado == "CLARO_CINEMA") {
$alfin = "739489";
}
elseif ($id_solicitado == "CLARO_SPORTS_COL") {
$alfin = "778943";
}
elseif ($id_solicitado == "CNN_INTERNACIONAL") {
$alfin = "773820";
}
elseif ($id_solicitado == "COMEDY_CENTRAL_HD") {
$alfin = "739487";
}
elseif ($id_solicitado == "CRISTOVISION") {
$alfin = "778883";
}
elseif ($id_solicitado == "DATA_IFX") {
$alfin = "778866";
}
elseif ($id_solicitado == "DEPELICULA") {
$alfin = "778900";
}
elseif ($id_solicitado == "DHE_HD") {
$alfin = "778928";
}
elseif ($id_solicitado == "DIA_TV_HD") {
$alfin = "717019";
}
elseif ($id_solicitado == "DISCOVERY_CHANNEL_HD") {
$alfin = "778876";
}
elseif ($id_solicitado == "DISCOVERY_CIVILIZATION") {
$alfin = "778844";
}
elseif ($id_solicitado == "DISCOVERY_HOME_HEALTH_HD") {
$alfin = "778886";
}
elseif ($id_solicitado == "DISCOVERY_KIDS_HD") {
$alfin = "762226";
}
elseif ($id_solicitado == "DISCOVERY_SCIENCE") {
$alfin = "778832";
}
elseif ($id_solicitado == "DISCOVERY_THEATER_HD") {
$alfin = "739491";
}
elseif ($id_solicitado == "DISCOVERY_TURBO") {
$alfin = "762225";
}
elseif ($id_solicitado == "DISCOVERY_TURBO_HD") {
$alfin = "778939";
}
elseif ($id_solicitado == "DISCOVERY_WORLD_HD") {
$alfin = "762254";
}
elseif ($id_solicitado == "DISNEY_HD") {
$alfin = "762205";
}
elseif ($id_solicitado == "DISNEY_JR") {
$alfin = "762195";
}
elseif ($id_solicitado == "DISNEY_XD") {
$alfin = "762238";
}
elseif ($id_solicitado == "DW") {
$alfin = "778878";
}
elseif ($id_solicitado == "DW_AMERIKA") {
$alfin = "778815";
}
elseif ($id_solicitado == "E") {
$alfin = "758554";
}
elseif ($id_solicitado == "EL_SEMBRADOR") {
$alfin = "762227";
}
elseif ($id_solicitado == "ENLACE") {
$alfin = "778852";
}
elseif ($id_solicitado == "EUROCHANNEL") {
$alfin = "778899";
}
elseif ($id_solicitado == "EWTN") {
$alfin = "762258";
}
elseif ($id_solicitado == "FRANCE24") {
$alfin = "762216";
}
elseif ($id_solicitado == "FXMX_HD") {
$alfin = "762769";
}
elseif ($id_solicitado == "FX_HD") {
$alfin = "773893";
}
elseif ($id_solicitado == "FOOD_NETWORK_HD") {
$alfin = "766229";
}
elseif ($id_solicitado == "GOLDEN") {
$alfin = "764008";
}
elseif ($id_solicitado == "GOLF_CHANNEL_HD") {
$alfin = "778891";
}
elseif ($id_solicitado == "GOURMET_HD") {
$alfin = "762255";
}
elseif ($id_solicitado == "GLITZ") {
$alfin = "778794";
}
elseif ($id_solicitado == "H2_HD") {
$alfin = "778958";
}
elseif ($id_solicitado == "HISTORY_CHANNEL_HD") {
$alfin = "758390";
}
elseif ($id_solicitado == "HLN") {
$alfin = "773802";
}
elseif ($id_solicitado == "HEADLINE_NEWS") {
$alfin = "759356";
}
elseif ($id_solicitado == "HOLA_TV_HD") {
$alfin = "778960";
}
elseif ($id_solicitado == "IBERO") {
$alfin = "755402";
}
elseif ($id_solicitado == "ID_HD") {
$alfin = "758466";
}
elseif ($id_solicitado == "INTI_HD") {
$alfin = "778911";
}
elseif ($id_solicitado == "ISAT") {
$alfin = "773959";
}
elseif ($id_solicitado == "LIFETIME") {
$alfin = "759386";
}
elseif ($id_solicitado == "MASCHIC_HD") {
$alfin = "778833";
}
elseif ($id_solicitado == "MAX") {
$alfin = "758568";
}
elseif ($id_solicitado == "MTV_HD") {
$alfin = "739478";
}
elseif ($id_solicitado == "MTV_HITS") {
$alfin = "778862";
}
elseif ($id_solicitado == "MTV_LIVE_HD") {
$alfin = "778874";
}
elseif ($id_solicitado == "MULTIPREMIER") {
$alfin = "762283";
}
elseif ($id_solicitado == "NATGEOKIDS_MX_HD") {
$alfin = "762800";
}
elseif ($id_solicitado == "NATGEOWILD_MX_HD") {
$alfin = "762786";
}
elseif ($id_solicitado == "NATGEO_HD") {
$alfin = "728274";
}
elseif ($id_solicitado == "NATGEO_KIDS_HD") {
$alfin = "773758";
}
elseif ($id_solicitado == "NATGEO_MX_HD") {
$alfin = "762770";
}
elseif ($id_solicitado == "NATGEO_WILD_HD") {
$alfin = "739492";
}
elseif ($id_solicitado == "NICKELODEON_HD") {
$alfin = "762233";
}
elseif ($id_solicitado == "NICK_2_HD") {
$alfin = "778857";
}
elseif ($id_solicitado == "NICK_JR_HD") {
$alfin = "762270";
}
elseif ($id_solicitado == "NICK_JR") {
$alfin = "728276";
}
elseif ($id_solicitado == "NICK_JR_HD") {
$alfin = "778906";
}
elseif ($id_solicitado == "NICKTOONS") {
$alfin = "778793";
}
elseif ($id_solicitado == "NTN24") {
$alfin = "778867";
}
elseif ($id_solicitado == "NTN24_2") {
$alfin = "778867";
}
elseif ($id_solicitado == "NHK") {
$alfin = "778917";
}
elseif ($id_solicitado == "ORBE") {
$alfin = "780890";
}
elseif ($id_solicitado == "PARAMOUNT_HD") {
$alfin = "762305";
}
elseif ($id_solicitado == "PASIONES_HD") {
$alfin = "762286";
}
elseif ($id_solicitado == "RAI") {
$alfin = "762240";
}
elseif ($id_solicitado == "SONY_HD") {
$alfin = "762280";
}
elseif ($id_solicitado == "STUDIO_UNIVERSAL") {
$alfin = "768737";
}
elseif ($id_solicitado == "SYFY_HD") {
$alfin = "778924";
}
elseif ($id_solicitado == "SUNDANCE_HD") {
$alfin = "762256";
}
elseif ($id_solicitado == "TBS_HD") {
$alfin = "763499";
}
elseif ($id_solicitado == "TCM") {
$alfin = "773941";
}
elseif ($id_solicitado == "TELEHIT") {
$alfin = "778863";
}
elseif ($id_solicitado == "TELEANTIOQUIA") {
$alfin = "778840";
}
elseif ($id_solicitado == "TELEANTIOQUIA_2") {
$alfin = "778840";
}
elseif ($id_solicitado == "TELECAFE") {
$alfin = "768767";
}
elseif ($id_solicitado == "TELECAFE_2") {
$alfin = "778859";
}
elseif ($id_solicitado == "TELEPACIFICO") {
$alfin = "766239";
}
elseif ($id_solicitado == "THE_FILM_ZONE_HD") {
$alfin = "773876";
}
elseif ($id_solicitado == "FILM_ARTS_HD") {
$alfin = "778894";
}
elseif ($id_solicitado == "TLC") {
$alfin = "758421";
}
elseif ($id_solicitado == "TLC_HD") {
$alfin = "763347";
}
elseif ($id_solicitado == "TNT_HD") {
$alfin = "773875";
}
elseif ($id_solicitado == "TNT_SERIES_HD") {
$alfin = "773938";
}
elseif ($id_solicitado == "TRU_TV_HD") {
$alfin = "773784";
}
elseif ($id_solicitado == "TV5") {
$alfin = "762251";
}
elseif ($id_solicitado == "TVE") {
$alfin = "778848";
}
elseif ($id_solicitado == "TV_AGRO_HD") {
$alfin = "772019";
}
elseif ($id_solicitado == "TV_AGRO_HD_2") {
$alfin = "778921";
}
elseif ($id_solicitado == "UNICABLE_HD") {
$alfin = "778961";
}
elseif ($id_solicitado == "UNIVERSAL_CHANNEL_HD") {
$alfin = "768778";
}
elseif ($id_solicitado == "VEPLUSTV") {
$alfin = "762197";
}
elseif ($id_solicitado == "VH1_HD") {
$alfin = "778919";
}
elseif ($id_solicitado == "VH1_CLASSIC") {
$alfin = "778842";
}
elseif ($id_solicitado == "WARNER_HD") {
$alfin = "778946";
}
elseif ($id_solicitado == "INDYCAR_SERIES") {
$alfin = "782189";
}
elseif ($id_solicitado == "PENTHOUSE_HD") {
$alfin = "758498";
}
elseif ($id_solicitado == "PLAYBOY_HD") {
$alfin = "758462";
}
elseif ($id_solicitado == "TV_CHILE_HD") {
$alfin = "766250";
}
elseif ($id_solicitado == "ZOOM") {
$alfin = "778830";



}
//elseif ($id_solicitado == "CANAL") {
//$alfin = "ID";
//}
//762802
//762272
//762235
//762263
$carpeta = $id_solicitado;
if (!file_exists($carpeta)) {
    mkdir($carpeta, 0777, true);
}

?>
